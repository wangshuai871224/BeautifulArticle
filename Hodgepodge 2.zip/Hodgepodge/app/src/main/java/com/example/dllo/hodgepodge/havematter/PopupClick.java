package com.example.dllo.hodgepodge.havematter;

/**
 * Created by TaiF on 16/12/28.
 */

public interface PopupClick {
    void getPosition (int pos);

}
