package com.example.dllo.hodgepodge.mine.suggest;

import com.example.dllo.hodgepodge.R;
import com.example.dllo.hodgepodge.base.BaseActivity;

/**
 * Created by shuaiwang on 16/12/22.
 */
public class SuggestActivity extends BaseActivity{
    @Override
    protected int setLayout() {
        return R.layout.activity_suggest;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
