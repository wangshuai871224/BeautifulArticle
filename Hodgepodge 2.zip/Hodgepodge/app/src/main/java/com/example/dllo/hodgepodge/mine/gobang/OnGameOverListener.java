package com.example.dllo.hodgepodge.mine.gobang;

/**
 * 庭
 * Created by Ting on 16/12/29.
 */

public interface OnGameOverListener {
    void gameOver(boolean isWhiteWinner);
}
