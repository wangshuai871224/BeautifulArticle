package com.example.dllo.hodgepodge.mine.msgcenter;

import com.example.dllo.hodgepodge.R;
import com.example.dllo.hodgepodge.base.BaseActivity;

/**
 * Created by shuaiwang on 16/12/22.
 */

public class MsgCenterActivity extends BaseActivity{
    @Override
    protected int setLayout() {
        return R.layout.activity_msg_center;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
