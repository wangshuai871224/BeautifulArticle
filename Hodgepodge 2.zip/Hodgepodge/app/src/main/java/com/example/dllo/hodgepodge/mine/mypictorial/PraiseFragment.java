package com.example.dllo.hodgepodge.mine.mypictorial;

import com.example.dllo.hodgepodge.R;
import com.example.dllo.hodgepodge.base.BaseFragment;

/**
 * Created by shuaiwang on 16/12/26.
 */
public class PraiseFragment extends BaseFragment {
    @Override
    protected int setLayout() {
        return R.layout.fragment_praise;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
